'use strict';

module.exports = {
  subscribe: (context) => {
    console.log('RECEIVED EVENT: ', context)
  }
};
